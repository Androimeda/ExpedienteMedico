CREATE TRIGGER TIPOCENTRO_ID_TIPO_CENTRO_TRG
BEFORE INSERT
  ON TIPOCENTRO
FOR EACH ROW WHEN (FOR EACH ROW )
BEGIN
    :new.id_tipo_centro := tipocentro_id_tipo_centro_seq.nextval;
END;
/
