CREATE TRIGGER TIPOSANGRE_ID_TIPO_SANGRE_TRG
BEFORE INSERT
  ON TIPOSANGRE
FOR EACH ROW WHEN (FOR EACH ROW )
BEGIN
    :new.id_tipo_sangre := tiposangre_id_tipo_sangre_seq.nextval;
END;
/
